package nomina;

import java.util.Scanner;

public class Operaciones {

    public void operaciones() {

    }

    public static void emp() {
        Scanner scanner = new Scanner(System.in);
        Scanner teclado = new Scanner(System.in);
        Scanner entrada = new Scanner(System.in);
        Operaciones operaciones = new Operaciones();
        var cte = 0;
        var nc = 0;
        var hlc = 0;
        var slb = 0;

        String te, n, a, rfc, curp, crt, tl;

        //Solicitar datos al usuario
        System.out.println("Ingrese la cantidad de empleados");
        cte = entrada.nextInt();
        System.out.println("Ingrese el n�mero de contrato:");
        nc = entrada.nextInt();
        System.out.println("Ingrese el tipo de empleado:");
        te = teclado.nextLine();
        System.out.println("Ingrese las horas laborales de contrato:");
        hlc = entrada.nextInt();
        System.out.println("Ingrese su salario base:");
        slb = teclado.nextInt();
        System.out.println("Ingrese su nombre:");
        n = teclado.nextLine();
        System.out.println("Ingrese sus apellidos:");
        a = teclado.nextLine();
        System.out.println("Ingrese su RFC:");
        rfc = teclado.nextLine();
        System.out.println("Ingrese su CURP:");
        curp = teclado.nextLine();
        System.out.println("Ingrese su correo electronico:");
        crt = teclado.nextLine();
        System.out.println("Ingrese su tel�fono:");
        tl = teclado.nextLine();
        System.out.println("A�os de Antig�eda"
                + "\n1. 0 a 2 a�os"
                + "\n2. 3 a 5 a�os"
                + "\n3. 6 a 10 a�os");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                operaciones.cd();
                break;

            case 2:
                operaciones.tc();
                break;

            case 3:
                operaciones.sd();
                break;

            case default:
                System.out.println("Elija una opci�n valida");
                break;
        }
        double isr = slb - 6602.71 * 21.36 + 699.30;
             //Salida de datos
        System.out.println("Hola " + n
                + " " + a);
        System.out.println("comprueba que tus datos sean correctos");
        System.out.println("N�mero de Contrato " + nc);
        System.out.println("Tipo de empleado " + te);
        System.out.println("Horas laborales de contrato " + hlc);
        System.out.println("Salario base: " + slb);
        System.out.println("RFC: " + rfc);
        System.out.println("CURP: " + curp);
        System.out.println("Correo Electronico: " + crt);
        System.out.println("Telefono: " + tl);
        System.out.println("ISR " + isr);

    }

    public void cd() {

    }

    public void tc() {
        Nomina nmn = new Nomina();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Empleado administrativo"
                + "\n1. Si"
                + "\n2. No");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                si();
                break;

            case 2:
                no();
                break;

            case default:
                System.out.println("Eliga una opci�n valida");
                break;
        }
    }

    public static void si() {
        System.out.println("Su bono sera de: " + slb * 0.04);

    }

    private static void no() {
        System.out.println("Su bono sera de: " + slb * 0.03);

    }

    public void sd() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Empleado administrativo"
                + "\n1. Si"
                + "\n2. No");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                si2();
                break;

            case 2:
                no2();
                break;

            case default:
                System.out.println("Eliga una opci�n valida");
                break;
        }
    }

    public static void si2() {
        System.out.println("Su bono sera de: " + slb * 0.12);

    }

    private static void no2() {
        System.out.println("Su bono sera de: " + slb * 0.08);

    }

}
