package nomina;

import java.util.Scanner;

public class Nomina {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Elija una sucursal"
                + "\n1. Matriz Teziutlan"
                + "\n2. Sucursal CDMX"
                + "\n3. Sucursal Malecon Veracruz");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                Operaciones.emp();
                break;

            case 2:
                Operaciones.emp();
                break;

            case 3:
                Operaciones.emp();
                break;

            case default:
                System.out.println("Elija una opcion valida");
                break;

         }

     }

    
    

    
    public Nomina() {
    }

}

